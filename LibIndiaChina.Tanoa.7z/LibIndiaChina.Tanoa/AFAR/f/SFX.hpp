#define AFAR_sfx
#define AFAR titles[]={""};
class in0 {name="in0";sound[]={"@A3\Dubbing_Radio_F\sfx\in2a.ogg",db+10,1.1};AFAR};
class in1 {name="in1";sound[]={"@A3\Dubbing_Radio_F\sfx\in2a.ogg",db+10,1};AFAR};
class in2 {name="in2";sound[]={"@A3\Dubbing_Radio_F\sfx\in2a.ogg",db+10,.7};AFAR};
class out1 {name="out1";sound[]={"@A3\Dubbing_Radio_F\sfx\out2a.ogg",db+6,1};AFAR};
class fuz0 {name="fuz0";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+5,1};AFAR};
class fuz1 {name="fuz1";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+8,1};AFAR};
class fuz2 {name="fuz2";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+11,1};AFAR};
class fuz3 {name="fuz3";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+14,1};AFAR};
class fuz4 {name="fuz4";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+17,1};AFAR};
class fuz5 {name="fuz5";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+20,1};AFAR};
class fuz6 {name="fuz6";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+23,1};AFAR};
class fuz7 {name="fuz7";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+26,1};AFAR};
class fuz8 {name="fuz8";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+28,1};AFAR};
class fuz9 {name="fuz9";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise1.ogg",db+30,1};AFAR};

class r_f0 {name="r_f0";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+5,1};AFAR};
class r_f1 {name="r_f1";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+8,1};AFAR};
class r_f2 {name="r_f2";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+11,1};AFAR};
class r_f3 {name="r_f3";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+14,1};AFAR};
class r_f4 {name="r_f4";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+17,1};AFAR};
class r_f5 {name="r_f5";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+20,1};AFAR};
class r_f6 {name="r_f6";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+23,1};AFAR};
class r_f7 {name="r_f7";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+26,1};AFAR};
class r_f8 {name="r_f8";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+28,1};AFAR};
class r_f9 {name="r_f9";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise2.ogg",db+30,1};AFAR};

class r_0f {name="r_0f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+5,1};AFAR};
class r_1f {name="r_1f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+8,1};AFAR};
class r_2f {name="r_2f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+11,1};AFAR};
class r_3f {name="r_3f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+14,1};AFAR};
class r_4f {name="r_4f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+17,1};AFAR};
class r_5f {name="r_5f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+20,1};AFAR};
class r_6f {name="r_6f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+23,1};AFAR};
class r_7f {name="r_7f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+26,1};AFAR};
class r_8f {name="r_8f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+28,1};AFAR};
class r_9f {name="r_9f";sound[]={"@A3\Dubbing_Radio_F\sfx\radionoise3.ogg",db+30,1};AFAR};