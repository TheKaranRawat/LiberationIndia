class AIS_Damage
{
    class AIS_Damage
    {
        file = "AIS\Damage";
		class exitDamageHandler;
		class getHitIndexValue;
		class goToDead;
		class handleDamage;
		class verifyDamageType;
    };
};